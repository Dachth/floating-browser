package com.example.speedwidget

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "SpeedWidget\n\nกดค้างที่หน้าจอหลัก > วิดเจ็ต > SpeedWidget\nเพื่อเพิ่มวิดเจ็ตลงหน้าจอ"
        tv.textSize = 18f
        tv.setPadding(48, 96, 48, 48)
        setContentView(tv)
    }
}
