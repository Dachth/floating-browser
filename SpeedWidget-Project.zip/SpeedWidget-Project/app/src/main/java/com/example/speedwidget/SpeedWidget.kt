package com.example.speedwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.RemoteViews

class SpeedWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val views = RemoteViews(context.packageName, R.layout.widget_speed)

        // ปุ่ม 1: Phone Master ของ HiOS (ถ้าไม่พบ จะเปิดหน้าตั้งค่าแทน)
        val master = context.packageManager
            .getLaunchIntentForPackage("com.transsion.phonemaster")
            ?: Intent(Settings.ACTION_SETTINGS)
        views.setOnClickPendingIntent(R.id.btn_master, pending(context, 0, master))

        // ปุ่ม 2: พื้นที่เก็บข้อมูล
        views.setOnClickPendingIntent(
            R.id.btn_storage,
            pending(context, 1, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        )

        // ปุ่ม 3: รายการแอพทั้งหมด (ปิด/ถอนแอพที่ไม่ใช้)
        views.setOnClickPendingIntent(
            R.id.btn_apps,
            pending(context, 2, Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
        )

        // ปุ่ม 4: ตัวเลือกนักพัฒนา (ลดแอนิเมชันเป็น 0.5x)
        views.setOnClickPendingIntent(
            R.id.btn_dev,
            pending(context, 3, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        )

        for (id in ids) manager.updateAppWidget(id, views)
    }

    private fun pending(context: Context, code: Int, intent: Intent): PendingIntent {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            context, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
