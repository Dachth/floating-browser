package com.example.floatingbrowser

import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.floatingbrowser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    private lateinit var binding: ActivityMainBinding
    private val activeWindows = mutableListOf<FloatingWebWindow>()
    private val maxWindows = 4

    private val sampleUrls = listOf(
        "https://www.google.com",
        "https://en.wikipedia.org",
        "https://github.com",
        "https://news.ycombinator.com"
    )
    private var urlIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSpawnWindow.setOnClickListener {
            if (activeWindows.size >= maxWindows) {
                Toast.makeText(this, "Maximum limit of $maxWindows windows reached", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val url = sampleUrls[urlIndex % sampleUrls.size]
            urlIndex++
            spawnWindow(url)
        }

        spawnWindow(sampleUrls[0])
    }

    private fun spawnWindow(url: String) {
        val window = FloatingWebWindow(
            context = this,
            initialUrl = url,
            onCloseRequested = { win ->
                binding.windowContainer.removeView(win)
                activeWindows.remove(win)
            },
            onCreateNewWindowRequested = { newUrl ->
                if (activeWindows.size < maxWindows && !newUrl.isNullOrEmpty()) {
                    spawnWindow(newUrl)
                }
            }
        )

        val offset = (activeWindows.size * 70).toFloat()
        window.x = 80f + offset
        window.y = 80f + offset

        binding.windowContainer.addView(window)
        activeWindows.add(window)
    }

    override fun onDestroy() {
        super.onDestroy()
        activeWindows.forEach { it.cleanup() }
        activeWindows.clear()
    }
}
