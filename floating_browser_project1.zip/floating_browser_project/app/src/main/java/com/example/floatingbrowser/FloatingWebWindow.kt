package com.example.floatingbrowser

import android.annotation.SuppressLint
import android.content.Context
import android.os.Message
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import com.example.floatingbrowser.databinding.ViewFloatingWebWindowBinding

@SuppressLint("ViewConstructor")
class FloatingWebWindow @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    private val initialUrl: String = "https://www.google.com",
    private val onCloseRequested: (FloatingWebWindow) -> Unit = {},
    private val onCreateNewWindowRequested: (String?) -> Unit = {}
) : FrameLayout(context, attrs, defStyleAttr) {

    private val binding: ViewFloatingWebWindowBinding =
        ViewFloatingWebWindowBinding.inflate(LayoutInflater.from(context), this, true)

    private var isCollapsed = false
    private var expandedHeight = 900
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    init {
        setupWindowProperties()
        setupWebView()
        setupInteractions()
    }

    private fun setupWindowProperties() {
        layoutParams = LayoutParams(750, 900)
        elevation = 10f
        setBackgroundColor(0xFFFFFFFF.toInt())

        binding.btnClose.setOnClickListener {
            cleanup()
            onCloseRequested(this)
        }

        binding.btnCollapse.setOnClickListener {
            toggleCollapse()
        }

        setOnTouchListener { _, _ ->
            bringToFront()
            false
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportMultipleWindows(true)
            settings.javaScriptCanOpenWindowsAutomatically = true

            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.tvTitle.text = url ?: initialUrl
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: Message?
                ): Boolean {
                    val newWebView = WebView(context).apply {
                        settings.javaScriptEnabled = true
                    }
                    val transport = resultMsg?.obj as? WebView.WebViewTransport
                    transport?.webview = newWebView
                    resultMsg?.sendToTarget()

                    newWebView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            onCreateNewWindowRequested(url)
                        }
                    }
                    return true
                }
            }

            loadUrl(initialUrl)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupInteractions() {
        binding.titleBar.setOnTouchListener { _, event ->
            bringToFront()
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastTouchX
                    val dy = event.rawY - lastTouchY
                    x += dx
                    y += dy
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    true
                }
                else -> false
            }
        }

        binding.resizeHandle.setOnTouchListener { _, event ->
            bringToFront()
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastTouchX
                    val dy = event.rawY - lastTouchY

                    val newWidth = (width + dx).coerceIn(350, 1400)
                    val newHeight = (height + dy).coerceIn(200, 2000)

                    val lp = layoutParams
                    lp.width = newWidth
                    lp.height = newHeight
                    layoutParams = lp

                    if (!isCollapsed) {
                        expandedHeight = newHeight
                    }

                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleCollapse() {
        val lp = layoutParams
        if (isCollapsed) {
            lp.height = expandedHeight
            binding.webView.visibility = VISIBLE
            isCollapsed = false
        } else {
            expandedHeight = height
            val titleBarHeight = (40 * resources.displayMetrics.density).toInt()
            lp.height = titleBarHeight
            binding.webView.visibility = GONE
            isCollapsed = true
        }
        layoutParams = lp
    }

    fun cleanup() {
        binding.webView.stopLoading()
        binding.webView.destroy()
    }
}
